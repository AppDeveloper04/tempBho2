//
//  ExportVC.m
//  SalaryApp
//
//  Created by Nilesh Pal on 28/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ExportVC.h"
#import "CellExport.h"
#import "HistoryDetailVC.h"
@interface ExportVC ()
{
    NSArray *list;
    NSArray *dataArr;
    NSDictionary *tempDic;
}
@property (weak, nonatomic) IBOutlet UITableView *tblExportList;
@end

@implementation ExportVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    tempDic = @{@"1":@"January",@"2": @"February", @"3":@"March",@"4": @"April", @"5":@"May", @"6":@"June", @"7":@"July", @"8":@"August", @"9":@"September", @"10":@"October", @"11":@"November", @"12":@"December"};
    
    self.title=@"Export History";
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectZero];
    [self.tblExportList setTableFooterView:view];
    
    
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask,
                                                         YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *documentDirPath = [documentsDir
                                 stringByAppendingPathComponent:FileName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL success = [fileManager fileExistsAtPath:documentDirPath];
    
    
    if (success) {
        [self fetchData];
    }
    else {
        [self callGetSalaryService];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - UITableView Delegate & Datasrouce -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [list count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellExport *cell = (CellExport *)[tableView dequeueReusableCellWithIdentifier:@"CellExport"];
    //year month
    [cell setData:[NSString stringWithFormat:@"%@ %@",tempDic[list[indexPath.row][@"month"]],list[indexPath.row][@"year"]]];
    [cell setBackgroundColor:[UIColor clearColor]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    HistoryDetailVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"HistoryDetailVC"];
    vc.titleStr = [NSString stringWithFormat:@"%@ %@",tempDic[list[indexPath.row][@"month"]],list[indexPath.row][@"year"]];
    vc.dict= [NSDictionary dictionaryWithDictionary:list[indexPath.row]];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Call WebApi

-(void)callGetSalaryService {
    
    if ([SharedInstance isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [SharedInstance callGetWebServiceWithURL:[NSString stringWithFormat:@"%@%@",SALARY_URL,[USER_PREF valueForKey:@"EmployeeId"]] andgetData:^(NSArray *data, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if (data.count>0) {
                    
                    
                    dataArr = [NSArray arrayWithArray:data];
                    
                    NSSortDescriptor *brandDescriptor = [[NSSortDescriptor alloc] initWithKey:@"year" ascending:NO];
                    NSArray *sortDescriptors = [NSArray arrayWithObject:brandDescriptor];
                    NSArray *sortedArray = [dataArr sortedArrayUsingDescriptors:sortDescriptors];
                    dataArr = [NSMutableArray arrayWithArray:sortedArray];
                    
                    brandDescriptor = [[NSSortDescriptor alloc] initWithKey:@"month" ascending:NO];
                    sortDescriptors = [NSArray arrayWithObject:brandDescriptor];
                    sortedArray = [dataArr sortedArrayUsingDescriptors:sortDescriptors];
                    dataArr = [NSMutableArray arrayWithArray:sortedArray];
                    
                    [self addToMyPlist];
                }
                else {
                    [SharedInstance showAlert:serverNotResponding andTitle:alertTitle];
                }
            }
            else {
                [SharedInstance showAlert:error.description andTitle:alertTitle];
            }
            
        }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

- (NSString *)copyFileToDocumentDirectory:(NSString *)fileName {
    
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask,
                                                         YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *documentDirPath = [documentsDir
                                 stringByAppendingPathComponent:fileName];
    
    NSArray *file = [fileName componentsSeparatedByString:@"."];
    NSString *filePath = [[NSBundle mainBundle]
                          pathForResource:[file objectAtIndex:0]
                          ofType:[file lastObject]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL success = [fileManager fileExistsAtPath:documentDirPath];
    
    if (!success) {
        success = [fileManager copyItemAtPath:filePath
                                       toPath:documentDirPath
                                        error:&error];
        if (!success) {
            NSAssert1(0, @"Failed to create writable txt file file with message \
                      '%@'.", [error localizedDescription]);
        }
    }
    
    return documentDirPath;
}

- (void)addToMyPlist {
    // set file manager object
    NSFileManager *manager = [NSFileManager defaultManager];
    
    // check if file exists
    NSString *plistPath = [self copyFileToDocumentDirectory:
                           FileName];
    
    BOOL isExist = [manager fileExistsAtPath:plistPath];
    // BOOL done = NO;
    
    if (!isExist) {
        // NSLog(@"MyPlistFile.plist does not exist");
        // done = [manager copyItemAtPath:file toPath:fileName error:&error];
    }
    // NSLog(@"done: %d",done);
    
    // write data to  plist file
    //BOOL isWritten = [plistArray writeToFile:plistPath atomically:YES];
    [dataArr writeToFile:plistPath atomically:YES];
    
    [self fetchData];
    
    // check for status
    // NSLog(@" \n  written == %d",isWritten);
}

- (void)fetchData {
    NSString *plistFilePath  = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:FileName];
    
    list = [NSArray arrayWithContentsOfFile:plistFilePath];
    NSLog(@"%@",list);
    [_tblExportList reloadData];

    
}

@end
