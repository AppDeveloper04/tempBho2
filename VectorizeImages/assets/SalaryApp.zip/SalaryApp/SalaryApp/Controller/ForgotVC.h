//
//  ForgotVC.h
//  SalaryApp
//
//  Created by Nilesh Pal on 26/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgotVC : UIViewController<SAMenuDropDownDelegate>

@property (nonatomic, strong) SAMenuDropDown *menuDrop;
@property (weak, nonatomic) IBOutlet UILabel *lblQuestion;
@property (weak, nonatomic) IBOutlet UIButton *btnDropDown;
@property (weak, nonatomic) IBOutlet UITextField *txtId;
@property (weak, nonatomic) IBOutlet UITextField *txtEmailId;
@property (weak, nonatomic) IBOutlet UITextField *txtAnswer;
@property (weak, nonatomic) IBOutlet UITextField *txtQuestion;

- (IBAction)action_DropDownClicked:(id)sender;
- (IBAction)action_Done:(id)sender;

@end
