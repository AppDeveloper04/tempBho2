//
//  ContactVC.h
//  SalaryApp
//
//  Created by Nilesh Pal on 28/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
@interface ContactVC : UIViewController<SlideNavigationControllerDelegate,MFMailComposeViewControllerDelegate,UINavigationControllerDelegate>

@end
