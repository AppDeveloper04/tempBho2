//
//  LeftMenuViewController.m
//  SalaryApp
//
//  Created by Nilesh Pal on 25/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "LeftMenuViewController.h"
#import "HomeVC.h"
#import "SettingVC.h"
#import "ContactVC.h"
#import "ExportVC.h"
#import "ExportXLS.h"
@implementation LeftMenuViewController

#pragma mark - UIViewController Methods -

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self.slideOutAnimationEnabled = YES;
    
    return [super initWithCoder:aDecoder];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.tableView.separatorColor = [UIColor lightGrayColor];
    dataArr = @[@"Last Month Statistics",@"Export to XLS",@"History",@"Contact Us",@"Settings",@"Logout"];
    [self.tableView setFrame:self.view.frame];

    self.view.layer.borderWidth = .6;
    self.view.layer.borderColor = [UIColor lightGrayColor].CGColor;

    UIView *view = [[UIView alloc]initWithFrame:CGRectZero];
    [self.tableView setTableFooterView:view];
}


#pragma mark - UITableView Delegate & Datasrouce -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataArr count];
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"leftMenuCell"];
    cell.textLabel.text = dataArr[indexPath.row];
    cell.backgroundColor = [UIColor clearColor];
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    HomeVC *vcHome = [mainStoryboard instantiateViewControllerWithIdentifier: @"HomeVC"];
    
    switch (indexPath.row)
    {
        case 0:
            
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vcHome
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            break;
            
        case 1:
        {
            ExportXLS *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ExportXLS"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
            break;
        }
            
        case 2:
        {
            ExportVC *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ExportVC"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
        
            break; }
            
        case 3:
        {
            ContactVC *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ContactVC"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc
             withSlideOutAnimation:self.slideOutAnimationEnabled
                     andCompletion:nil];
        
            break;}
            
        case 4:{
            SettingVC *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"SettingVC"];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc
                                                                     withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                             andCompletion:nil];
        
            break;}
            
        case 5:
            [self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
            [USER_PREF setValue:@"" forKey:@"EmployeeId"];
            [USER_PREF setBool:NO forKey:@"LoggedIn"];
            [USER_PREF synchronize];
            [[SlideNavigationController sharedInstance] popToRootViewControllerAnimated:NO];
            return;
            break;
            
            
    }
    
    
}

@end
