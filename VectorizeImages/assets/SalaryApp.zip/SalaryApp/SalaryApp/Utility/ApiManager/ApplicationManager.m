//
//  ApplicationManager.m
//  SalaryApp
//
//  Created by Nilesh Pal on 25/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ApplicationManager.h"
#import "Constant.h"
#import "Reachability.h"

@implementation ApplicationManager

+ (id)sharedManagerInstance {
    
    static ApplicationManager *sharedManager = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [[self alloc] init];
    });
    
    return sharedManager;
}

#pragma mark - Validation Methods

- (BOOL)isNetworkConnected {
    
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    return networkStatus != NotReachable;
}


#pragma mark - Show Alert

-(void)showAlert:(NSString *)message andTitle:(NSString *)title {
    
    [[[UIAlertView alloc]initWithTitle:title message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
}

#pragma mark - WebAPIs

- (void)callGetWebServiceWithURL:(NSString *)urlString andgetData:(StringConsumer) consumer {
    
    NSString *tempString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:tempString]];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:60];

    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue]  completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        NSString *responseString=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"Response string post ==%@",responseString);
        
        if ([(NSHTTPURLResponse *)response statusCode]==200)
        {
            
            NSError* error;
            NSArray *json = [NSJSONSerialization
                                  JSONObjectWithData:data
                                  options:kNilOptions
                                  error:&error];
            
            consumer(json,nil);
            
        }
        else
        {
            consumer(nil,error);
        }
    }];
}

@end
