//
//  AboutUsVC.h
//  SalaryApp
//
//  Created by Nilesh Pal on 02/08/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUsVC : UIViewController

@end
