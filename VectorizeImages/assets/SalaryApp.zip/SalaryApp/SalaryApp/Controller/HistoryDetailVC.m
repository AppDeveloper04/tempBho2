//
//  HistoryDetailVC.m
//  SalaryApp
//
//  Created by Nilesh on 8/4/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "HistoryDetailVC.h"

@interface HistoryDetailVC ()

@end

@implementation HistoryDetailVC
@synthesize dict,titleStr;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title =  self.titleStr;
    
            _lblDegree.text = [NSString stringWithFormat:@"%@/%@",dict[@"degree"],dict[@"step"]];
            _lblBasicSalary.text = dict[@"basicsalary"];
            _lblYearMonth.text = [NSString stringWithFormat:@"%@/%@",dict[@"year"],dict[@"month"]];
            _lblNet.text = dict[@"netsalary"];
            _lblAllow.text = dict[@"allownce"];
            _lblDeduction.text = dict[@"deduction"];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
