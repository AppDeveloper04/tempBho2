//
//  CellExport.m
//  SalaryApp
//
//  Created by Nilesh Pal on 28/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "CellExport.h"

@implementation CellExport

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setData :(NSString *)strName
{
    [self.lblName setText:[NSString stringWithFormat:@"%@",strName]];
}

@end
