//
//  SettingVC.m
//  SalaryApp
//
//  Created by Nilesh Pal on 27/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "SettingVC.h"

@interface SettingVC ()
@property (weak, nonatomic) IBOutlet UIButton *btnChangePassword;
@property (weak, nonatomic) IBOutlet UIButton *bntSubcription;
@property (weak, nonatomic) IBOutlet UISwitch *switchNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnAboutUS;

@end

@implementation SettingVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"Settings";
    // Do any additional setup after loading the view.
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - Actions

-(IBAction)ActionbtnChangePassword:(id)sender
{
    
}


-(IBAction)ActionbntSubcription:(id)sender
{
    
}


-(IBAction)ActionbtnAboutUS:(id)sender
{
    
}

-(IBAction)ActionSwitchNotification:(id)sender
{
    
}


@end
