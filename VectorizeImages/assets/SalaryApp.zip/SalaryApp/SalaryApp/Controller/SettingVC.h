//
//  SettingVC.h
//  SalaryApp
//
//  Created by Dheerendra chaturvedi on 27/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingVC : UIViewController<SlideNavigationControllerDelegate>

@end
