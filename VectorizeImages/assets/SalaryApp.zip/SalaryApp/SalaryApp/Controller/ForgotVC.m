//
//  ForgotVC.m
//  SalaryApp
//
//  Created by Nilesh Pal on 26/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ForgotVC.h"

@interface ForgotVC ()
{
    BOOL isDropDownOpen;
    NSMutableArray *arrQues;
    BOOL iskeyboardOpen;
    CGRect originalFrame;
    UITextField *activeTxt;
}
@end

@implementation ForgotVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    iskeyboardOpen = NO;
    originalFrame = self.view.frame;
    
    self.navigationController.navigationBarHidden = NO;
    self.title = @"Forgot Password";
    
    [self callGetQuestionService];

    isDropDownOpen= NO;
    // Do any additional setup after loading the view.
}

- (void)viewDidAppear:(BOOL) animated {
    [super viewDidAppear:animated];
    // Register notification when the keyboard will be show
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    // Register notification when the keyboard will be hide
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}

- (void)keyboardWillShow:(NSNotification *)notification {
    
    if (!iskeyboardOpen && [activeTxt isEqual:_txtAnswer]) {
        iskeyboardOpen = YES;
        float height = [[notification.userInfo valueForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
        self.view.frame = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y - height, self.view.frame.size.width, self.view.frame.size.height);
    }
    
    
    
    // Do something with keyboard height
}

- (void)keyboardWillHide:(NSNotification *)notification {
    
    iskeyboardOpen = NO;

    self.view.frame = originalFrame;
    // Do something with keyboard height
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    activeTxt = textField;
}

#pragma mark - Action


- (IBAction)action_DropDownClicked:(id)sender {
    if (isDropDownOpen) {
        isDropDownOpen=NO;
        [_menuDrop hideSADropDownMenu];
        
    }
    else {
        isDropDownOpen=YES;
        [_menuDrop showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
    }
}

- (IBAction)action_Done:(id)sender {
    if (_txtAnswer.text.length >0 && _txtId.text.length > 0 && _txtEmailId.text.length > 0 && _txtQuestion.text.length > 0) {
        
        if ([SharedInstance emailAddressIsValid:_txtEmailId.text]) {
           [self callGetPasswordService];
        }
        else {
            [SharedInstance showAlert:@"Please Enter Valid EmailId" andTitle:alertTitle];
        }
    }
    else {
         [SharedInstance showAlert:@"All fields are mandatory" andTitle:alertTitle];
    }
}

#pragma mark - Dropdown delegate method

- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex
{
    
    [_txtQuestion setText:[NSString stringWithFormat:@" %@",arrQues[buttonIndex]]];
    isDropDownOpen=NO;
    [_menuDrop hideSADropDownMenu];
    
}

#pragma mark - Call WebApi

-(void)callGetQuestionService {
    
    if ([SharedInstance isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [SharedInstance callGetWebServiceWithURL:GET_QUESTION_URL andgetData:^(NSArray *data, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if (data.count>0) {
                    
                    arrQues = [NSMutableArray new];
                    
                    for (NSDictionary *temp in data) {
                        [arrQues addObject:temp[@"QueName"]];
                    }
                    
                    _menuDrop = [[SAMenuDropDown alloc] initWithWithSource:_btnDropDown menuHeight:160.0 itemNames:arrQues itemImagesName:nil itemSubtitles:nil];
                    _menuDrop.delegate = self;
                }
                else {
                    [SharedInstance showAlert:serverNotResponding andTitle:alertTitle];
                }
            }
            else {
                [SharedInstance showAlert:error.description andTitle:alertTitle];
            }
            
        }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

-(void)callGetPasswordService {
    
    if ([SharedInstance isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [SharedInstance callGetWebServiceWithURL:[NSString stringWithFormat:@"%@%@/%@/%@/%@",FORGOT_PASSWORD,_txtId.text,_txtQuestion.text,_txtAnswer.text,_txtEmailId.text] andgetData:^(NSArray *data, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if (data.count>0) {
                    [SharedInstance showAlert:data[0][@"message"] andTitle:alertTitle];
                    if ([data[0][@"status"] boolValue]) {
                        
                        [self.navigationController popViewControllerAnimated:YES];
                    }
                    
                }
                else {
                    [SharedInstance showAlert:serverNotResponding andTitle:alertTitle];
                }
            }
            else {
                [SharedInstance showAlert:error.description andTitle:alertTitle];
            }
            
        }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

@end
