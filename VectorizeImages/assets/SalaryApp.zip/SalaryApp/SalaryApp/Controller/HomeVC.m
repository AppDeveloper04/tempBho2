//
//  HomeVC.m
//  SalaryApp
//
//  Created by Nilesh Pal on 25/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "HomeVC.h"

@interface HomeVC ()
{
    NSArray *dataArr;
}
@end

@implementation HomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSCalendar * calendar = [NSCalendar currentCalendar];
    
    NSDateComponents * currentDateComponents = [calendar components: NSCalendarUnitYear | NSCalendarUnitMonth fromDate: [NSDate date]];
    NSDate * startOfMonth = [calendar dateFromComponents: currentDateComponents];

    
    self.title = [NSString stringWithFormat:@"Welcome %@",[USER_PREF valueForKey:@"EmployeeName"]];
    
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask,
                                                         YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *documentDirPath = [documentsDir
                                 stringByAppendingPathComponent:FileName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL success = [fileManager fileExistsAtPath:documentDirPath];
    
    
    if (success) {
        [self fetchData];
    }
    else {
        [self callGetSalaryService];
    }
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - Call WebApi

-(void)callGetSalaryService {
    
    if ([SharedInstance isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [SharedInstance callGetWebServiceWithURL:[NSString stringWithFormat:@"%@%@",SALARY_URL,[USER_PREF valueForKey:@"EmployeeId"]] andgetData:^(NSArray *data, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if (data.count>0) {
                    

                    dataArr = [NSArray arrayWithArray:data];
                    
                    NSSortDescriptor *brandDescriptor = [[NSSortDescriptor alloc] initWithKey:@"year" ascending:NO];
                    NSArray *sortDescriptors = [NSArray arrayWithObject:brandDescriptor];
                    NSArray *sortedArray = [dataArr sortedArrayUsingDescriptors:sortDescriptors];
                    dataArr = [NSMutableArray arrayWithArray:sortedArray];
                    
                    brandDescriptor = [[NSSortDescriptor alloc] initWithKey:@"month" ascending:NO];
                    sortDescriptors = [NSArray arrayWithObject:brandDescriptor];
                    sortedArray = [dataArr sortedArrayUsingDescriptors:sortDescriptors];
                    dataArr = [NSMutableArray arrayWithArray:sortedArray];
                    
                    [self addToMyPlist];
                }
                else {
                    [SharedInstance showAlert:serverNotResponding andTitle:alertTitle];
                }
            }
            else {
                [SharedInstance showAlert:error.description andTitle:alertTitle];
            }
            
        }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

- (NSString *)copyFileToDocumentDirectory:(NSString *)fileName {
    
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask,
                                                         YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *documentDirPath = [documentsDir
                                 stringByAppendingPathComponent:fileName];
    
    NSArray *file = [fileName componentsSeparatedByString:@"."];
    NSString *filePath = [[NSBundle mainBundle]
                          pathForResource:[file objectAtIndex:0]
                          ofType:[file lastObject]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL success = [fileManager fileExistsAtPath:documentDirPath];
    
    if (!success) {
        success = [fileManager copyItemAtPath:filePath
                                       toPath:documentDirPath
                                        error:&error];
        if (!success) {
            NSAssert1(0, @"Failed to create writable txt file file with message \
                      '%@'.", [error localizedDescription]);
        }
    }
    
    return documentDirPath;
}

- (void)addToMyPlist {
    // set file manager object
    NSFileManager *manager = [NSFileManager defaultManager];
    
    // check if file exists
    NSString *plistPath = [self copyFileToDocumentDirectory:
                           FileName];
    
    BOOL isExist = [manager fileExistsAtPath:plistPath];
    // BOOL done = NO;
    
    if (!isExist) {
        // NSLog(@"MyPlistFile.plist does not exist");
        // done = [manager copyItemAtPath:file toPath:fileName error:&error];
    }
    // NSLog(@"done: %d",done);

    // write data to  plist file
    //BOOL isWritten = [plistArray writeToFile:plistPath atomically:YES];
    [dataArr writeToFile:plistPath atomically:YES];

    [self fetchData];
    
    // check for status
    // NSLog(@" \n  written == %d",isWritten);
}

- (void)fetchData {
    NSString *plistFilePath  = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:FileName];
    
    NSArray *list = [NSArray arrayWithContentsOfFile:plistFilePath];
    NSLog(@"%@",list);
    
    if (list.count > 0) {
        _lblDegree.text = [NSString stringWithFormat:@"%@/%@",list[0][@"degree"],list[0][@"step"]];
        _lblBasicSalary.text = list[0][@"basicsalary"];
        _lblYearMonth.text = [NSString stringWithFormat:@"%@/%@",list[0][@"year"],list[0][@"month"]];
        _lblNet.text = list[0][@"netsalary"];
        _lblAllow.text = list[0][@"allownce"];
        _lblDeduction.text = list[0][@"deduction"];
    }
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
