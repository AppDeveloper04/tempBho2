//
//  LoginVC.m
//  SalaryApp
//
//  Created by Nilesh Pal on 25/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "LoginVC.h"
#import "HomeVC.h"
@interface LoginVC ()

@end

@implementation LoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if ([USER_PREF boolForKey:@"LoggedIn"]) {
        HomeVC *vc= [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
        [self.navigationController pushViewController:vc animated:NO];
    }
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBarHidden = YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITextField Delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - Action

- (IBAction)action_login:(id)sender {
    
    if (_txtUserName.text.length>0 && _txtPassword.text.length>0) {
        [self callLoginService];
    }
    else {
        [SharedInstance showAlert:@"Please Enter Your LoginId & Password." andTitle:alertTitle];
    }
    
}


#pragma mark - Call WebApi

-(void)callLoginService {
    
    if ([SharedInstance isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [SharedInstance callGetWebServiceWithURL:[NSString stringWithFormat:@"%@%@/%@",LOGIN_URL,_txtUserName.text,_txtPassword.text] andgetData:^(NSArray *data, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if (data.count>0) {
                    
                    [USER_PREF setValue:_txtUserName.text forKey:@"UserId"];
                    [USER_PREF setValue:data[0][@"employeeid"] forKey:@"EmployeeId"];
                    [USER_PREF setValue:data[0][@"employeename"] forKey:@"EmployeeName"];
                    [USER_PREF setBool:YES forKey:@"LoggedIn"];
                    [USER_PREF synchronize];
                    
                    _txtUserName.text = @"";
                    _txtPassword.text = @"";
                    
                    HomeVC *vc= [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
                    [self.navigationController pushViewController:vc animated:YES];
                }
                else {
                    [SharedInstance showAlert:@"Something wrong with credentials." andTitle:alertTitle];
                }
            }
            else {
                [SharedInstance showAlert:error.description andTitle:alertTitle];
            }
            
        }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

@end
