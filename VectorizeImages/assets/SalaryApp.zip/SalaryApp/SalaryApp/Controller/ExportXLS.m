//
//  ExportXLS.m
//  SalaryApp
//
//  Created by Dheerendra chaturvedi on 28/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ExportXLS.h"

@interface ExportXLS ()
{
    NSArray *monthArr;
    NSMutableArray *yearArr;
    BOOL selectData;
}
@property (weak, nonatomic) IBOutlet UILabel *lblMonth;
@property (weak, nonatomic) IBOutlet UILabel *lblYear;
@property (weak, nonatomic) IBOutlet UITextField *txtEmailID;
@property (weak, nonatomic) IBOutlet UIPickerView *pickerMonthYear;
@property (weak, nonatomic) IBOutlet UIToolbar *pickerTool;

@end

@implementation ExportXLS

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Export to XLS";
    
    monthArr = @[@"January", @"February", @"March", @"April", @"May", @"June", @"July", @"August", @"September", @"October", @"November", @"December"];
    for (int i= 2000; i<2100; i++) {
        [yearArr addObject:[NSString stringWithFormat:@"%d",i]];
    }
    
    selectData = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - Actions

- (IBAction)actionXLS:(id)sender {
}

#pragma mark - UIPickerView DataSource & Delegate

//- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
//    return 1;
//}
//
//- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
//    return dropDownArr.count;
//}
//
//- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
//    selectedPickerRow = row;
//}


@end
