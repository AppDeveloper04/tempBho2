//
//  Constant.h
//  SalaryApp
//
//  Created by Nilesh Pal on 25/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#ifndef SalaryApp_Constant_h
#define SalaryApp_Constant_h

// Alert Messages

#define networkNotConnected @"Internet connection not found, Please make sure that you are connected with internet"
#define serverNotResponding @"Something went wrong, Please try after some time"
#define alertTitle @"SalaryApp"


// Objects

#define USER_PREF [NSUserDefaults standardUserDefaults]

#define SharedInstance [ApplicationManager sharedManagerInstance]

#define ScreenSize [UIScreen mainScreen].bounds.size.height

// Webservice URLs

#define BASE_URL @"http://salaryservice.pandititsolutions.com/"

#define LOGIN_URL BASE_URL@"UserLogin.svc/Login/"

#define SALARY_URL BASE_URL@"Salary.svc/GetSalary/"

#define GET_QUESTION_URL BASE_URL@"UserRegister.svc/GetQuestion"

#define CHANGE_PASSWORD BASE_URL@"UserLogin.svc/ChangePassword/"

#define REGISTRATION BASE_URL@"UserRegister.svc/AddUser/"

#endif
