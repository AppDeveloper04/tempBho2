//
//  ContactVC.m
//  SalaryApp
//
//  Created by Nilesh Pal on 28/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ContactVC.h"

@interface ContactVC ()
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtContactNo;
@property (weak, nonatomic) IBOutlet UITextField *txtEmaillD;
@property (weak, nonatomic) IBOutlet UITextView *txtmessage;

@end

@implementation ContactVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Contact Us";
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = YES;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark-Action

- (IBAction)ActionBtnSend:(id)sender {

    if (_txtContactNo.text.length > 0 && _txtEmaillD.text.length > 0 && _txtName.text.length > 0 && _txtmessage.text.length > 0) {
        if ([SharedInstance emailAddressIsValid:_txtEmaillD.text]) {
                [self sendMail];
        }
        else {
            [SharedInstance showAlert:@"Please Enter Valid EmailId" andTitle:alertTitle];
        }
    }
    else {
        [SharedInstance showAlert:@"All fields are mandatory" andTitle:alertTitle];
    }
    
}

- (void) sendMail {

    MFMailComposeViewController* controller = [[MFMailComposeViewController alloc] init];
    controller.mailComposeDelegate = self;
    controller.delegate = self;

    [controller setSubject:@"Salary App"];
    
    NSString *str= [NSString stringWithFormat:@"Name = %@\nContact No. = %@\nEmail Id = %@\nMessage = %@",_txtName.text,_txtContactNo.text,_txtEmaillD.text,_txtmessage.text];
    
    [controller setMessageBody:str isHTML:NO];

    if (controller) {
        [self presentViewController:controller animated:YES completion:nil];
    }
    
}


- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    NSString *messageBody= [[NSString alloc] init];
    switch (result)
    {
        case MFMailComposeResultCancelled:
            //DLog(@"Mail cancelled: you cancelled the operation and no email message was queued.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"You cancelled sending message";
            break;
            
        case MFMailComposeResultSaved:
            //DLog(@"Mail saved: you saved the email message in the drafts folder.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail saved: you saved the email message in the drafts folder'";
            break;
            
        case MFMailComposeResultSent:
            //DLog(@"Mail send: the email message is queued in the outbox. It is ready to send.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail has been sent";
            [self mailSent];
            break;
            
        case MFMailComposeResultFailed:
            //DLog(@"Mail failed: the email message was not saved or queued, possibly due to an error.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Email sending failed";
            break;
            
        default:
            //DLog(@"Mail not sent.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            break;
    }
    
    
}

- (void) mailSent
{
    //showing an alert for success
    [SharedInstance showAlert:@"Mail sent successfully." andTitle:alertTitle];
    
}

@end
