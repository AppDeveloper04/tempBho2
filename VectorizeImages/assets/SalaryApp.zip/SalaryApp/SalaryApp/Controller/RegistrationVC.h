//
//  RegistrationVC.h
//  SalaryApp
//
//  Created by Nilesh Pal on 25/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegistrationVC : UIViewController<SAMenuDropDownDelegate>

@property (weak, nonatomic) IBOutlet UIButton *btnRegister;
@property (nonatomic, strong) SAMenuDropDown *menuDrop;
@property (weak, nonatomic) IBOutlet UITextField *txtCompany;
@property (weak, nonatomic) IBOutlet UITextField *txtBadge;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
@property (weak, nonatomic) IBOutlet UIButton *btnDropDown;
@property (weak, nonatomic) IBOutlet UISwitch *pwdSwitch;
@property (weak, nonatomic) IBOutlet UITextField *txtSecQues;
@property (weak, nonatomic) IBOutlet UITextField *txtAnswer;

- (IBAction)action_Swirch:(id)sender;
- (IBAction)action_dropDown:(UIButton *)sender;
- (IBAction)action_Register:(id)sender;
@end
