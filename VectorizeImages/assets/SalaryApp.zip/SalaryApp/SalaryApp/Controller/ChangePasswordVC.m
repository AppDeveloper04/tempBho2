//
//  ChangePasswordVC.m
//  SalaryApp
//
//  Created by Nilesh Pal on 28/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ChangePasswordVC.h"

@interface ChangePasswordVC ()


@end

@implementation ChangePasswordVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Change Password";
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.hidesBackButton = NO;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITextField Delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark-Action


- (IBAction)action_ChangePwd:(id)sender {
    
    if (_txtOldPwd.text.length >0 && _txtNewPwd.text.length >0 && _txtConfirmPwd.text.length>0) {
        if ([_txtNewPwd.text isEqualToString:_txtConfirmPwd.text]) {
            [self callChangePwdService];
        }
        else {
            [SharedInstance showAlert:@"Password & Confirm pasword must be same." andTitle:alertTitle];
        }
    }
    else {
        [SharedInstance showAlert:@"All fields are mandatory." andTitle:alertTitle];
    }
    
}

#pragma mark - Call WebApi

-(void)callChangePwdService {
    
    if ([SharedInstance isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [SharedInstance callGetWebServiceWithURL:[NSString stringWithFormat:@"%@%@/%@/%@",CHANGE_PASSWORD,[USER_PREF valueForKey:@"UserId"],_txtOldPwd.text,_txtNewPwd.text] andgetData:^(NSArray *data, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if (data.count>0) {
                    if ([data[0][@"status"] boolValue]) {
                        [SharedInstance showAlert:@"Password changed successfully." andTitle:alertTitle];
                        [self.navigationController popViewControllerAnimated:YES];
                    }
                    else {
                        [SharedInstance showAlert:@"Failed to Change Password." andTitle:alertTitle];
                    }
                    
                }
                else {
                    [SharedInstance showAlert:serverNotResponding andTitle:alertTitle];
                }
            }
            else {
                [SharedInstance showAlert:error.description andTitle:alertTitle];
            }
            
        }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

@end
