//
//  HomeVC.h
//  SalaryApp
//
//  Created by Nilesh Pal on 25/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeVC : UIViewController<SlideNavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *lblDegree;
@property (weak, nonatomic) IBOutlet UILabel *lblBasicSalary;
@property (weak, nonatomic) IBOutlet UILabel *lblYearMonth;
@property (weak, nonatomic) IBOutlet UILabel *lblNet;
@property (weak, nonatomic) IBOutlet UILabel *lblAllow;
@property (weak, nonatomic) IBOutlet UILabel *lblDeduction;

@end
