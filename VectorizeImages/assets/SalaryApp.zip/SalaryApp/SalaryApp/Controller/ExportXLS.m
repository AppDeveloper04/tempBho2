//
//  ExportXLS.m
//  SalaryApp
//
//  Created by Nilesh Pal on 28/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ExportXLS.h"
#import "RSworkBook.h"
#import "RSworkSheet.h"
#import "RSworkSheetRow.h"
@interface ExportXLS ()
{
    NSArray *monthArr,*numberArr;
    NSMutableArray *yearArr;
    BOOL selectData;
    NSArray *pickerArr;
    NSString *selectedString;
    UITextField *selectedTxt;
    NSString *monthStr;
    NSArray *list;
    NSArray *dataArr;
    NSMutableString *csv;
    NSArray *salaryArr;
}
@property (weak, nonatomic) IBOutlet UITextField *txtMonth;
@property (weak, nonatomic) IBOutlet UITextField *txtYear;
@property (weak, nonatomic) IBOutlet UITextField *txtEmailID;
@property (weak, nonatomic) IBOutlet UIPickerView *pickerMonthYear;
@property (weak, nonatomic) IBOutlet UIToolbar *pickerTool;

@end

@implementation ExportXLS

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Export to XLS";
    yearArr = [NSMutableArray new];
    salaryArr = [NSArray new];
    monthArr = @[@"January", @"February", @"March", @"April", @"May", @"June", @"July", @"August", @"September", @"October", @"November", @"December"];
    numberArr = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12"];
    for (int i= 2000; i<2100; i++) {
        [yearArr addObject:[NSString stringWithFormat:@"%d",i]];
    }
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask,
                                                         YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *documentDirPath = [documentsDir
                                 stringByAppendingPathComponent:FileName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL success = [fileManager fileExistsAtPath:documentDirPath];
    
    
    if (!success) {
        [self callGetSalaryService];
    }

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - Actions

- (IBAction)actionXLS:(id)sender {
    if (_txtMonth.text.length > 0 && _txtEmailID.text.length > 0 && _txtYear.text.length > 0) {
        if ([SharedInstance emailAddressIsValid:_txtEmailID.text]) {
            
            salaryArr=[self fetchData];

            if (salaryArr.count > 0) {
                /*
                 (
                 {
                 allownce = 1642600;
                 basicsalary = 644000;
                 deduction = 166191;
                 degree = 6;
                 message = "Get Salary Successfully";
                 month = 5;
                 netsalary = 1476409;
                 status = 1;
                 step = 2;
                 year = 2015;
                 }
                 )
                 
                 
                 */
//                
//                RSworkBook * folder = [ [RSworkBook alloc] init];
//                folder.author = @"Nilesh Pal";
//                folder.version = 1.0;
//                
//                RSworkSheet * sheet = [[RSworkSheet alloc] initWithName:@"Salary"];
//                
//                NSDictionary *dict = salaryArr[0];
//                NSArray *arr = [dict allKeys];
//                for (int i = 0; i < [arr count]; i++) {
//                    
//                    if ([arr[i]  isEqualToString: @"status"]) {
//                        
//                    }
//                    else  if ([arr[i]  isEqualToString: @"message"]) {
//                        
//                    }
//                    else {
//                    RSworkSheetRow * row = [[RSworkSheetRow alloc] initWithHeight:20];
//                    [row addCellString:arr[i]];
//                    [row addCellString:dict[arr[i]]];
//                    [sheet addWorkSheetRow:row];
//                    }
//                    
//                }
//
//                
//                [folder addWorkSheet:sheet];
                
//                NSDictionary *dict = salaryArr[0];
//                                NSArray *arr = [dict allKeys];
//                NSMutableString *csv = [NSMutableString stringWithString:@"Key,Value"];
//                
//                for (int i = 0; i < [arr count]; i++) {
//                    
//                    if ([arr[i]  isEqualToString: @"status"]) {
//                        
//                    }
//                    else  if ([arr[i]  isEqualToString: @"message"]) {
//                        
//                    }
//                    else {
//                        [csv appendFormat:@"\n\"%@\",%@\"",arr[i],dict[arr[i]]];
//                       
//                    }
//                    
//                }
//                
//                
//                
//                NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
//                                                                     NSUserDomainMask,
//                                                                     YES);
//                NSString *documentsDir = [paths objectAtIndex:0];
//                NSString *documentDirPath = [documentsDir
//                                             stringByAppendingPathComponent:@"Salary.xls"];
//                NSError *error;
//                BOOL res = [csv writeToFile:documentDirPath atomically:YES encoding:NSUTF8StringEncoding error:&error];
//                
//                if (!res) {
//                    NSLog(@"Error %@ while writing to file", [error localizedDescription]);
//                }

                NSDictionary *dict = salaryArr[0];
                NSArray *arr = [dict allKeys];
                csv = [NSMutableString new];
                
                for (int i = 0; i < [arr count]; i++) {
                    
                    if ([arr[i]  isEqualToString: @"status"]) {
                        
                    }
                    else  if ([arr[i]  isEqualToString: @"message"]) {
                        
                    }
                    else {
                        [csv appendFormat:@"%@ = %@\n",arr[i],dict[arr[i]]];
                        
                    }
                    
                }
                [self sendMail];
            }
            else {
                [SharedInstance showAlert:@"Details not found." andTitle:alertTitle];
            }
            
           
        }
        else {
            [SharedInstance showAlert:@"Please Enter Valid EmailId" andTitle:alertTitle];
        }
    }
    else {
        [SharedInstance showAlert:@"All fields are mandatory" andTitle:alertTitle];
    }
}
- (IBAction)picker_Done:(id)sender {
    selectedTxt.text = selectedString;
    [self.view endEditing:YES];
}
- (IBAction)picker_Action:(id)sender {
    [self.view endEditing:YES];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (_txtMonth == textField) {
        pickerArr = [NSArray arrayWithArray:monthArr];
        [_pickerMonthYear reloadAllComponents];
        textField.inputView = _pickerMonthYear;
        textField.inputAccessoryView = _pickerTool;
        selectedTxt = textField;
    }
    else if (_txtYear == textField) {
        pickerArr = [NSArray arrayWithArray:yearArr];
        [_pickerMonthYear reloadAllComponents];
        textField.inputView = _pickerMonthYear;
        textField.inputAccessoryView = _pickerTool;
        selectedTxt = textField;
    }
    else {
        
    }
}

#pragma mark - UIPickerView DataSource & Delegate

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return pickerArr.count;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    selectedString = pickerArr[row];
    if (selectedTxt == _txtMonth) {
        monthStr = numberArr[row];
    }
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return pickerArr[row];
}

#pragma mark - Call WebApi

-(void)callGetSalaryService {
    
    if ([SharedInstance isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [SharedInstance callGetWebServiceWithURL:[NSString stringWithFormat:@"%@%@",SALARY_URL,[USER_PREF valueForKey:@"EmployeeId"]] andgetData:^(NSArray *data, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if (data.count>0) {
                    
                    
                    dataArr = [NSArray arrayWithArray:data];
                    
                    NSSortDescriptor *brandDescriptor = [[NSSortDescriptor alloc] initWithKey:@"year" ascending:NO];
                    NSArray *sortDescriptors = [NSArray arrayWithObject:brandDescriptor];
                    NSArray *sortedArray = [dataArr sortedArrayUsingDescriptors:sortDescriptors];
                    dataArr = [NSMutableArray arrayWithArray:sortedArray];
                    
                    brandDescriptor = [[NSSortDescriptor alloc] initWithKey:@"month" ascending:NO];
                    sortDescriptors = [NSArray arrayWithObject:brandDescriptor];
                    sortedArray = [dataArr sortedArrayUsingDescriptors:sortDescriptors];
                    dataArr = [NSMutableArray arrayWithArray:sortedArray];
                    
                    [self addToMyPlist];
                }
                else {
                    [SharedInstance showAlert:serverNotResponding andTitle:alertTitle];
                }
            }
            else {
                [SharedInstance showAlert:error.description andTitle:alertTitle];
            }
            
        }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

- (NSString *)copyFileToDocumentDirectory:(NSString *)fileName {
    
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask,
                                                         YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *documentDirPath = [documentsDir
                                 stringByAppendingPathComponent:fileName];
    
    NSArray *file = [fileName componentsSeparatedByString:@"."];
    NSString *filePath = [[NSBundle mainBundle]
                          pathForResource:[file objectAtIndex:0]
                          ofType:[file lastObject]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL success = [fileManager fileExistsAtPath:documentDirPath];
    
    if (!success) {
        success = [fileManager copyItemAtPath:filePath
                                       toPath:documentDirPath
                                        error:&error];
        if (!success) {
            NSAssert1(0, @"Failed to create writable txt file file with message \
                      '%@'.", [error localizedDescription]);
        }
    }
    
    return documentDirPath;
}

- (void)addToMyPlist {
    // set file manager object
    NSFileManager *manager = [NSFileManager defaultManager];
    
    // check if file exists
    NSString *plistPath = [self copyFileToDocumentDirectory:
                           FileName];
    
    BOOL isExist = [manager fileExistsAtPath:plistPath];
    // BOOL done = NO;
    
    if (!isExist) {
        // NSLog(@"MyPlistFile.plist does not exist");
        // done = [manager copyItemAtPath:file toPath:fileName error:&error];
    }
    // NSLog(@"done: %d",done);
    
    // write data to  plist file
    //BOOL isWritten = [plistArray writeToFile:plistPath atomically:YES];
    [dataArr writeToFile:plistPath atomically:YES];
    
    
    
    // check for status
    // NSLog(@" \n  written == %d",isWritten);
}

- (NSArray *)fetchData {
    NSString *plistFilePath  = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:FileName];
    
    list = [NSArray arrayWithContentsOfFile:plistFilePath];

    
    NSArray *filteredarray = [list filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"(year == %@) && (month == %@)", _txtYear.text,monthStr]];
    return filteredarray;
    
}

- (void) sendMail {
    
    MFMailComposeViewController* controller = [[MFMailComposeViewController alloc] init];
    controller.mailComposeDelegate = self;
    controller.delegate = self;
    
    [controller setSubject:@"Salary App"];
    [controller setToRecipients:@[_txtEmailID.text]];
//    NSString *str= [NSString stringWithFormat:@"Name = %@\nContact No. = %@\nEmail Id = %@\nMessage = %@",_txtName.text,_txtContactNo.text,_txtEmaillD.text,_txtmessage.text];
    
    [controller setMessageBody:csv isHTML:NO];
    
    if (controller) {
        [self presentViewController:controller animated:YES completion:nil];
    }
    
}


- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    NSString *messageBody= [[NSString alloc] init];
    switch (result)
    {
        case MFMailComposeResultCancelled:
            //DLog(@"Mail cancelled: you cancelled the operation and no email message was queued.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"You cancelled sending message";
            break;
            
        case MFMailComposeResultSaved:
            //DLog(@"Mail saved: you saved the email message in the drafts folder.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail saved: you saved the email message in the drafts folder'";
            break;
            
        case MFMailComposeResultSent:
            //DLog(@"Mail send: the email message is queued in the outbox. It is ready to send.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Mail has been sent";
            [self mailSent];
            break;
            
        case MFMailComposeResultFailed:
            //DLog(@"Mail failed: the email message was not saved or queued, possibly due to an error.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            messageBody = @"Email sending failed";
            break;
            
        default:
            //DLog(@"Mail not sent.");
            [self dismissViewControllerAnimated:YES
                                     completion:nil];
            break;
    }
    
    
}

- (void) mailSent
{
    //showing an alert for success
    [SharedInstance showAlert:@"Mail sent successfully." andTitle:alertTitle];
    
}

@end
