//
//  NSCell.m
//  excelWriterExample
//
//  Created by andrea cappellotto on 15/09/11.
//  Copyright 2011 Università degli studi di Trento. All rights reserved.
//

#import "RSCell.h"

@implementation RSCell
@synthesize style, content, type;
- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
