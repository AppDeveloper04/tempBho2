//
//  HistoryDetailVC.h
//  SalaryApp
//
//  Created by Nilesh on 8/4/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryDetailVC : UIViewController

@property (strong,nonatomic) NSDictionary *dict;
@property (strong, nonatomic)NSString *titleStr;
@property (weak, nonatomic) IBOutlet UILabel *lblDegree;
@property (weak, nonatomic) IBOutlet UILabel *lblBasicSalary;
@property (weak, nonatomic) IBOutlet UILabel *lblYearMonth;
@property (weak, nonatomic) IBOutlet UILabel *lblNet;
@property (weak, nonatomic) IBOutlet UILabel *lblAllow;
@property (weak, nonatomic) IBOutlet UILabel *lblDeduction;
@end
