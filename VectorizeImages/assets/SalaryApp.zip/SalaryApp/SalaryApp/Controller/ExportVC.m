//
//  ExportVC.m
//  SalaryApp
//
//  Created by Dheerendra chaturvedi on 28/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ExportVC.h"
#import "CellExport.h"
@interface ExportVC ()
{
    NSMutableArray *arrayExportList;
}
@property (weak, nonatomic) IBOutlet UITableView *tblExportList;
@end

@implementation ExportVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Export History";
    arrayExportList=[[NSMutableArray alloc]initWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7", nil];
    [_tblExportList reloadData];
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectZero];
    [self.tblExportList setTableFooterView:view];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - UITableView Delegate & Datasrouce -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayExportList count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellExport *cell = (CellExport *)[tableView dequeueReusableCellWithIdentifier:@"CellExport"];
    
    [cell setData:[arrayExportList objectAtIndex:indexPath.row]];
    [cell setBackgroundColor:[UIColor clearColor]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


@end
