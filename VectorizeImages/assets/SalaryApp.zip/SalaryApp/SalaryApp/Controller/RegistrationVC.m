//
//  RegistrationVC.m
//  SalaryApp
//
//  Created by Nilesh Pal on 25/07/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "RegistrationVC.h"

@interface RegistrationVC ()
{
    BOOL isDropDownOpen;
    NSMutableArray *arrQues;
}
@end

@implementation RegistrationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden = NO;
    self.title = @"Registration";
    
    [self callGetQuestionService];
    
    isDropDownOpen= NO;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Action 

- (IBAction)action_Swirch:(id)sender {
    
    if (_pwdSwitch.isOn) {
         [_txtPassword setSecureTextEntry:NO];
    }
    else {
        [_txtPassword setSecureTextEntry:YES];
    }
}

- (IBAction)action_dropDown:(UIButton *)sender {
    if (isDropDownOpen) {
        isDropDownOpen=NO;
        [_menuDrop hideSADropDownMenu];
        
    }
    else {
        isDropDownOpen=YES;
        [_menuDrop showSADropDownMenuWithAnimation:kSAMenuDropAnimationDirectionBottom];
    }
}

- (IBAction)action_Register:(id)sender {
    if (_txtCompany.text.length>0 && _txtBadge.text.length>0 && _txtPassword.text.length>0 && _txtSecQues.text.length>0 && _txtAnswer.text.length>0) {
        [self callRegistrationService];
    }
    else {
        [SharedInstance showAlert:@"All fields are mandatory" andTitle:alertTitle];
    }
}

#pragma mark - Dropdown delegate method

- (void)saDropMenu:(SAMenuDropDown *)menuSender didClickedAtIndex:(NSInteger)buttonIndex
{
    
    [_txtSecQues setText:[NSString stringWithFormat:@" %@",arrQues[buttonIndex]]];
    isDropDownOpen=NO;
    [_menuDrop hideSADropDownMenu];
    
}

#pragma mark - Call WebApi

-(void)callGetQuestionService {
    
    if ([SharedInstance isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [SharedInstance callGetWebServiceWithURL:GET_QUESTION_URL andgetData:^(NSArray *data, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if (data.count>0) {
                    
                    arrQues = [NSMutableArray new];
                    
                    for (NSDictionary *temp in data) {
                        [arrQues addObject:temp[@"QueName"]];
                    }
                    
                    _menuDrop = [[SAMenuDropDown alloc] initWithWithSource:_btnDropDown menuHeight:160.0 itemNames:arrQues itemImagesName:nil itemSubtitles:nil];
                    _menuDrop.delegate = self;
                }
                else {
                    [SharedInstance showAlert:serverNotResponding andTitle:alertTitle];
                }
            }
            else {
                [SharedInstance showAlert:error.description andTitle:alertTitle];
            }
            
        }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}

-(void)callRegistrationService {
    
    if ([SharedInstance isNetworkConnected]) {
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [SharedInstance callGetWebServiceWithURL:[NSString stringWithFormat:@"%@%@/%@/%@/%@/%@/",REGISTRATION,_txtBadge.text,_txtPassword.text,_txtCompany.text,_txtSecQues.text,_txtAnswer.text,@""] andgetData:^(NSArray *data, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (data) {
                if (data.count>0) {
                    
                }
                else {
                    [SharedInstance showAlert:serverNotResponding andTitle:alertTitle];
                }
            }
            else {
                [SharedInstance showAlert:error.description andTitle:alertTitle];
            }
            
        }];
    }
    else {
        [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
    }
}


@end
